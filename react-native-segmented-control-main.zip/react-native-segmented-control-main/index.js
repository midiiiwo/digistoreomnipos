import SegmentedControl from './src/segmentedControl';

export default SegmentedControl;